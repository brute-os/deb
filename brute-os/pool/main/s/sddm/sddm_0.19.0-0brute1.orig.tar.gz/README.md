# Official Brute OS sddm pkg
Brute OS dev <brute-os@outlook.com>
---
sddm pkg source repo : `https://gitlab.com/brute-os/packages/sddm.git`
---

Copyright (C) 2023 Arijit Bhowmick <arijit_bhowmick@outlook.com> <br>
Author: Arijit Bhowmick <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/brute-os/packages/sddm/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm/-/tree/dev">DEV</a> <br>
</h6>

<hr>
<p align="center">
Developed with ❤️
</p>
