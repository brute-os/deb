# Official Brute OS sddm-theme-extra pkgs
Brute OS dev <brute-os@outlook.com>
---
sddm pkg source repo : `https://gitlab.com/brute-os/packages/sddm-theme-extra.git`
---

Copyright (C) 2023 Arijit Bhowmick <arijit_bhowmick@outlook.com> <br>
Author: Arijit Bhowmick <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/brute-os/packages/sddm-theme-extra/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm-theme-extra/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm-theme-extra/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm-theme-extra/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/brute-os/packages/sddm-theme-extra/-/tree/dev">DEV</a> <br>
</h6>


```text
  * Added 36 SDDM themes to brute OS sddm-theme-extra package
    - sddm-theme-amiga-os-13
    - sddm-theme-amiga-os-classic
    - sddm-theme-amiga-os-pharaoh
    - sddm-theme-andromeda-kde
    - sddm-theme-c64-classic-fancy
    - sddm-theme-c64-classic
    - sddm-theme-c64-geos
    - sddm-theme-c64-gijoe
    - sddm-theme-c64-holiday
    - sddm-theme-c64-ik
    - sddm-theme-c64-lcp
    - sddm-theme-c64-ninja
    - sddm-theme-c64-robot
    - sddm-theme-c64-spacetaxi
    - sddm-theme-c64-summergames
    - sddm-theme-c64-timecrystal
    - sddm-theme-catppuccin-frappe
    - sddm-theme-catppuccin-latte
    - sddm-theme-catppuccin-macchiato
    - sddm-theme-catppuccin-mocha
    - sddm-theme-catppuccin-old
    - sddm-theme-dawn
    - sddm-theme-desktoppal97
    - sddm-theme-monochrome-red
    - sddm-theme-terminalstylelogin
    - sddm-theme-trellium-colorshift-dark
    - sddm-theme-trellium-colorshift
    - sddm-theme-trellium-colorshift-translucent
    - sddm-theme-trellium-dark
    - sddm-theme-trellium-inverted
    - sddm-theme-trellium-inverted-translucent
    - sddm-theme-trellium-rc3
    - sddm-theme-trellium-solid
    - sddm-theme-trellium-source
    - sddm-theme-venture
    - sddm-theme-win11
```

<hr>
<p align="center">
Developed with ❤️
</p>
