# Official Brute OS Wallpapers
Brute OS dev - <brute-os@outlook.co>
---
brute-os-wallpapers pkg source repo : https://gitlab.com/brute-os/packages/brute-os-wallpapers.git
---

Copyright (C) 2023 Arijit Bhowmick <arijit_bhowmick@outlook.com> <br>
License: GPL-3.0+ <br>
Author: Arijit Bhowmick <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-wallpapers/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-wallpapers/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-wallpapers/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-wallpapers/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-wallpapers/-/tree/dev">DEV</a> <br>
</h6>

<hr>
<p align="center">
Developed with ❤️
</p>
