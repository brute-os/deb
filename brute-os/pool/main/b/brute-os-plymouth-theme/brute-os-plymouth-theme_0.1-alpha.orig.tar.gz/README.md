# Official Brute OS Plymouth Theme
Brute OS dev <brute-os@outlook.com>
---
brute-os-plymouth-theme pkg source repo : `https://gitlab.com/brute-os/packages/brute-os-plymouth-theme.git`
---

Copyright (C) 2023 Arijit Bhowmick <arijit_bhowmick@outlook.com> <br>
License: GPL-3.0+ <br>
Author: Arijit Bhowmick <br>
Dependency: plymouth <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-plymouth-theme/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-plymouth-theme/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-plymouth-theme/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-plymouth-theme/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/brute-os/packages/brute-os-plymouth-theme/-/tree/dev">DEV</a> <br>
</h6>

<hr>
<p align="center">
Developed with ❤️
</p>
